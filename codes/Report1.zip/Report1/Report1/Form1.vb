﻿Option Explicit Off
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        student_id.Text = "634272109"
        student_Name.Text = "WISA CHIMNGAM"
        student_email.Text = "wisa.chi@mail.pbru.ac.th"

        Dim birthdate As Date = #2/21/2002#
        REM age As Integer

        age = Year(Today()) - Year(birthdate)
        dw = birthdate.DayOfWeek
        student_age.Text = age.ToString & "วันเกิด" & birthdate.ToString("dddd")
        Student_enroll.Text = (16000 * 8).ToString("฿#,###")
    End Sub
End Class
