﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.student_id = New System.Windows.Forms.Label()
        Me.student_Name = New System.Windows.Forms.Label()
        Me.student_email = New System.Windows.Forms.Label()
        Me.student_age = New System.Windows.Forms.Label()
        Me.Student_enroll = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Cyan
        Me.Button1.Location = New System.Drawing.Point(43, 27)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(183, 38)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "รายงานข้อมูลนักศึกษา"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'student_id
        '
        Me.student_id.AutoSize = True
        Me.student_id.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.student_id.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.student_id.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.student_id.Location = New System.Drawing.Point(43, 78)
        Me.student_id.Name = "student_id"
        Me.student_id.Size = New System.Drawing.Size(69, 18)
        Me.student_id.TabIndex = 1
        Me.student_id.Text = "รหัสนักศึกษา"
        '
        'student_Name
        '
        Me.student_Name.AutoSize = True
        Me.student_Name.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.student_Name.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.student_Name.Location = New System.Drawing.Point(43, 118)
        Me.student_Name.Name = "student_Name"
        Me.student_Name.Size = New System.Drawing.Size(61, 18)
        Me.student_Name.TabIndex = 2
        Me.student_Name.Text = "ชื่อนักศึกษา"
        '
        'student_email
        '
        Me.student_email.AutoSize = True
        Me.student_email.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.student_email.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.student_email.Location = New System.Drawing.Point(43, 156)
        Me.student_email.Name = "student_email"
        Me.student_email.Size = New System.Drawing.Size(70, 18)
        Me.student_email.TabIndex = 3
        Me.student_email.Text = "อีเมล์นักศึกษา"
        '
        'student_age
        '
        Me.student_age.AutoSize = True
        Me.student_age.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.student_age.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.student_age.Location = New System.Drawing.Point(43, 194)
        Me.student_age.Name = "student_age"
        Me.student_age.Size = New System.Drawing.Size(65, 18)
        Me.student_age.TabIndex = 4
        Me.student_age.Text = "อายุนักศึกษา"
        '
        'Student_enroll
        '
        Me.Student_enroll.AutoSize = True
        Me.Student_enroll.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Student_enroll.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Student_enroll.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Student_enroll.Location = New System.Drawing.Point(43, 227)
        Me.Student_enroll.Name = "Student_enroll"
        Me.Student_enroll.Size = New System.Drawing.Size(175, 22)
        Me.Student_enroll.TabIndex = 5
        Me.Student_enroll.Text = "ค่าลงทะเบียนตลอดหลักสูตร"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(412, 321)
        Me.Controls.Add(Me.Student_enroll)
        Me.Controls.Add(Me.student_age)
        Me.Controls.Add(Me.student_email)
        Me.Controls.Add(Me.student_Name)
        Me.Controls.Add(Me.student_id)
        Me.Controls.Add(Me.Button1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents student_id As System.Windows.Forms.Label
    Friend WithEvents student_Name As System.Windows.Forms.Label
    Friend WithEvents student_email As System.Windows.Forms.Label
    Friend WithEvents student_age As System.Windows.Forms.Label
    Friend WithEvents Student_enroll As System.Windows.Forms.Label

End Class
